using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondPlayerVisual : MonoBehaviour
{
    private Animator animator;

    private const string IS_RUNNING = "IsRunning";

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        animator.SetBool(IS_RUNNING, SecondPlayer.Instance.IsRunning());
    }
}

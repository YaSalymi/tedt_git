using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondGameInput : MonoBehaviour
{
    public static SecondGameInput Instance { get; private set; }

    private SecondInputMap playerInputMap;

    private void Awake()
    {
        Instance = this;

        playerInputMap = new SecondInputMap();
        playerInputMap.Enable();
    }

    public Vector2 GetMovementVector()
    {
        return playerInputMap.Player1.Move.ReadValue<Vector2>();
    }
}

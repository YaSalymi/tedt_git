using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

public class FirstPlayer : NetworkBehaviour
{
    public static FirstPlayer Instance { get; private set; }
    private Rigidbody2D rb;

    [SerializeField] private float movingSpeed = 5f;
    private float minMovingSpeed = 0.1f;
    private bool isRunning = false;

    private void Awake()
    {
        Instance = this;
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if (IsOwner == false)
            return;

        Movement();
    }

    private void Movement()
    {
        Vector2 inputVector = FirstGameInput.Instance.GetMovementVector();
        rb.MovePosition(rb.position + inputVector * (movingSpeed * Time.fixedDeltaTime));

        if (Mathf.Pow(Mathf.Pow(inputVector.x, 2) + Mathf.Pow(inputVector.y, 2), 0.5f) > minMovingSpeed)
        {
            isRunning = true;
        }
        else
        {
            isRunning = false;
        }
    }

    public bool IsRunning()
    {
        return isRunning;
    }
}

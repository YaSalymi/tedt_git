using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class FirstPlayerVisual : MonoBehaviour
{
    private Animator animator;

    private const string IS_RUNNING = "IsRunning";

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        if (FirstPlayer.Instance.IsOwner == false)
            return;

        animator.SetBool(IS_RUNNING, FirstPlayer.Instance.IsRunning());
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstGameInput : MonoBehaviour
{
    public static FirstGameInput Instance { get; private set; }

    private FirstInputMap playerInputMap;

    private void Awake()
    {
        Instance = this;

        playerInputMap = new FirstInputMap();
        playerInputMap.Enable();
    }

    public Vector2 GetMovementVector()
    {
        return playerInputMap.Player1.Move.ReadValue<Vector2>();
    }
}

using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.UI;

public class NetworkMainMenueUI : MonoBehaviour
{
    [SerializeField] private Button HostBotton;
    [SerializeField] private Button ClientBotton;

    private void Awake()
    {
        HostBotton.onClick.AddListener(OnStartHost);
        ClientBotton.onClick.AddListener(OnStartClient);
    }

    private void OnStartHost()
    {
        NetworkManager.Singleton.StartHost();
    }

    private void OnStartClient()
    {
        NetworkManager.Singleton.StartClient();
    }
}
